//
//  Model.swift
//  MPFramework
//
//  Created by Manish on 7/12/18.
//  Copyright © 2018 Aikya. All rights reserved.
//

import UIKit

open class Model: NSObject {
    open func printData() -> String {
        return "Working.................."
    }
}
