//
//  MPFramework.h
//  MPFramework
//
//  Created by Manish on 7/12/18.
//  Copyright © 2018 Aikya. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MPFramework.
FOUNDATION_EXPORT double MPFrameworkVersionNumber;

//! Project version string for MPFramework.
FOUNDATION_EXPORT const unsigned char MPFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MPFramework/PublicHeader.h>


