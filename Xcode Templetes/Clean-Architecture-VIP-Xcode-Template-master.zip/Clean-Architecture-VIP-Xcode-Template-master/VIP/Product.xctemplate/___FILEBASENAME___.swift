//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

public enum ___VARIABLE_productName:identifier___: Module {
    case home

    public var routePath: String {
        switch self {
        case .home:
            return "___PROJECTNAME___/Home"
        }
    }
}
