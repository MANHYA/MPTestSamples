//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol I___VARIABLE_productName:identifier___View: class {
	// do someting...
}

class ___VARIABLE_productName:identifier___View: UIView {
	// do someting...
}

extension ___VARIABLE_productName:identifier___View: I___VARIABLE_productName:identifier___View {
	// do someting...
}

extension ___VARIABLE_productName:identifier___View {
	// do someting...
}

extension ___VARIABLE_productName:identifier___View {
	// do someting...
}
