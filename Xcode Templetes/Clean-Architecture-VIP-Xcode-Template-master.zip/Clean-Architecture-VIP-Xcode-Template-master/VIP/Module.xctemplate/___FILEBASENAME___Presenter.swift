//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol I___VARIABLE_productName:identifier___Presenter: class {
	// do someting...
}

class ___VARIABLE_productName:identifier___Presenter: I___VARIABLE_productName:identifier___Presenter {	
	weak var view: I___VARIABLE_productName:identifier___ViewController!
	
	init(view: I___VARIABLE_productName:identifier___ViewController) {
		self.view = view
	}
}
