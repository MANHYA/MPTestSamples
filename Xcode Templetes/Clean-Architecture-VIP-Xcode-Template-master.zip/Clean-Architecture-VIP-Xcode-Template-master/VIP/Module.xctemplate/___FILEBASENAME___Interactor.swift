//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol I___VARIABLE_productName:identifier___Interactor: class {
	var parameters: [String: Any]? { get }
}

class ___VARIABLE_productName:identifier___Interactor: I___VARIABLE_productName:identifier___Interactor {
    var presenter: I___VARIABLE_productName:identifier___Presenter!
    var parameters: [String: Any]?

    private var manager: I___VARIABLE_productName:identifier___Manager {
        return ___VARIABLE_productName:identifier___Manager()
    }

    init(presenter: I___VARIABLE_productName:identifier___Presenter) {
    	self.presenter = presenter
    }
}
