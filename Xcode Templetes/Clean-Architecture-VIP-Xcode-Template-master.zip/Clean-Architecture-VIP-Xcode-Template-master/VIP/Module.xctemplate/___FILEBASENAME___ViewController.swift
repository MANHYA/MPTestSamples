//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol I___VARIABLE_productName:identifier___ViewController: class {
	// do someting...
}

class ___VARIABLE_productName:identifier___ViewController: UIViewController {
	var interactor: I___VARIABLE_productName:identifier___Interactor!
	var router: I___VARIABLE_productName:identifier___Router!

	override func viewDidLoad() {
        super.viewDidLoad()
		// do someting...
    }
}

extension ___VARIABLE_productName:identifier___ViewController: I___VARIABLE_productName:identifier___ViewController {
	// do someting...
}

extension ___VARIABLE_productName:identifier___ViewController {
	// do someting...
}

extension ___VARIABLE_productName:identifier___ViewController {
	// do someting...
}
