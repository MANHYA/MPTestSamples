//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import Foundation

protocol I___VARIABLE_productName:identifier___Manager: class {
	// do someting...
}

class ___VARIABLE_productName:identifier___Manager: I___VARIABLE_productName:identifier___Manager {
	// do someting...
}
