//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

class ___VARIABLE_productName:identifier___Module: IModule {
    let appRouter: IAppRouter
    private var router: ___VARIABLE_productName:identifier___Router!

    init(_ appRouter: IAppRouter) {
        self.appRouter = appRouter
        self.router = ___VARIABLE_productName:identifier___Router(appRouter: self.appRouter)
    }

    func presentView(parameters: [String: Any]) {
        router.presentView(parameters: parameters)
    }

    func createView(parameters: [String: Any]) -> UIViewController? {
        return router.create(parameters: parameters)
    }
}
