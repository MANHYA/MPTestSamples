# Clean-Architecture-VIP-Template
Clean Architecture VIP Template

Swift 5
Xcode 11+

How to use:

clone this repo in `cd ~/Library/Developer/Xcode/Templates`

To install the Clean Swift Xcode templates,run:
```bash
$ make install_templates
```

To uninstall the Clean Swift Xcode templates, run:
```bash
$ make uninstall_templates
```
